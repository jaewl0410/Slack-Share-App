plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.jwl.slackcopyshare"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.jwl.slackcopyshare.diagnostic"
        minSdk = 29
        targetSdk = 35
        versionCode = 11
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
}
