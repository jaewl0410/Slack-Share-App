package com.jwl.slackcopyshare

import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.provider.Settings
import android.transition.AutoTransition
import android.transition.TransitionManager
import android.view.View
import android.widget.Button
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView

class MainActivity : Activity() {
    private val purple = Color.rgb(74, 21, 75)
    private val ink = Color.rgb(34, 29, 37)
    private val muted = Color.rgb(102, 93, 106)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = purple
        window.navigationBarColor = Color.rgb(248, 246, 249)
        window.decorView.systemUiVisibility =
            View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(30), dp(20), dp(32))
            setBackgroundColor(Color.rgb(248, 246, 249))
        }
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(page)
        }

        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = android.view.Gravity.CENTER_VERTICAL
        }
        header.addView(ImageView(this).apply {
            setImageResource(R.drawable.app_icon)
            contentDescription = "슬랙 공유하기 아이콘"
        }, LinearLayout.LayoutParams(dp(76), dp(76)))
        header.addView(TextView(this).apply {
            text = getString(R.string.display_name)
            textSize = 24f
            setTextColor(ink)
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            setPadding(dp(16), 0, 0, 0)
        }, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        page.addView(header)

        val description = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(22), dp(20), dp(22))
            background = rounded(Color.WHITE, dp(20))
        }
        addSection(description, "소개", getString(R.string.introduction))
        addSection(description, "사용 방법", getString(R.string.instructions))
        addSection(description, "작동 원리", getString(R.string.how_it_works), false)
        page.addView(description, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT,
        ).apply { topMargin = dp(26) })

        val settingsButton = Button(this).apply {
            text = "접근성 설정 열기"
            textSize = 16f
            isAllCaps = false
            setTextColor(Color.WHITE)
            background = rounded(purple, dp(14))
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        }
        page.addView(settingsButton, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(56),
        ).apply { topMargin = dp(28) })

        val codeButton = Button(this).apply {
            text = "어플리케이션 코드 전문  ▾"
            textSize = 16f
            isAllCaps = false
            setTextColor(purple)
            background = rounded(Color.WHITE, dp(14), purple)
        }
        page.addView(codeButton, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(56),
        ).apply { topMargin = dp(12) })

        val codePanel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(dp(16), dp(16), dp(16), dp(20))
            background = rounded(Color.WHITE, dp(16))
        }
        codePanel.addView(TextView(this).apply {
            text = "앱 소스 코드"
            textSize = 16f
            setTextColor(ink)
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        })
        codePanel.addView(TextView(this).apply {
            text = assets.open("application_source.txt").bufferedReader(Charsets.UTF_8).use { it.readText() }
            textSize = 11f
            typeface = Typeface.MONOSPACE
            setTextColor(muted)
            setTextIsSelectable(true)
            setPadding(0, dp(12), 0, 0)
        })
        page.addView(codePanel, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT,
            LinearLayout.LayoutParams.WRAP_CONTENT,
        ).apply { topMargin = dp(12) })

        codeButton.setOnClickListener {
            val opening = codePanel.visibility != View.VISIBLE
            TransitionManager.beginDelayedTransition(page, AutoTransition().apply { duration = 180 })
            codePanel.visibility = if (opening) View.VISIBLE else View.GONE
            codeButton.text = if (opening) "어플리케이션 코드 전문  ▴" else "어플리케이션 코드 전문  ▾"
            if (opening) page.post { scroll.smoothScrollTo(0, codePanel.top) }
        }

        setContentView(scroll)
    }

    private fun addSection(parent: LinearLayout, label: String, body: String, spaceAfter: Boolean = true) {
        parent.addView(TextView(this).apply {
            text = label
            textSize = 14f
            setTextColor(purple)
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        })
        parent.addView(TextView(this).apply {
            text = body
            textSize = 16f
            setTextColor(ink)
            setLineSpacing(dp(4).toFloat(), 1f)
            setPadding(0, dp(6), 0, if (spaceAfter) dp(22) else 0)
        })
    }

    private fun rounded(color: Int, radius: Int, stroke: Int? = null) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius.toFloat()
        if (stroke != null) setStroke(dp(1), stroke)
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density + 0.5f).toInt()
}
