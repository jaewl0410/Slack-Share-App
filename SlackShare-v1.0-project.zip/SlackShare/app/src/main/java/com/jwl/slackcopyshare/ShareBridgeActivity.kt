package com.jwl.slackcopyshare

import android.app.Activity
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper

class ShareBridgeActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private var started = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onResume() {
        super.onResume()
        if (started) return
        started = true
        val automatic = intent.getBooleanExtra(EXTRA_AUTOMATIC, false)
        val key = if (automatic) "automatic" else "manual"
        Diagnostics.set(this, key, "브릿지 화면 열림 → 클립보드 확인 중")
        handler.postDelayed({ shareClipboard(key, 0) }, 250)
    }

    private fun shareClipboard(key: String, attempt: Int) {
        val text = try {
            val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = clipboard.primaryClip
            val triggeredAt = intent.getLongExtra(EXTRA_TRIGGERED_AT, 0L)
            val fresh = triggeredAt == 0L || (clip?.description?.timestamp ?: 0L) >= triggeredAt - 1000L
            clip?.takeIf { fresh && it.itemCount > 0 }
                ?.getItemAt(0)?.coerceToText(this)?.toString()?.takeIf { it.isNotBlank() }
        } catch (error: Exception) {
            Diagnostics.set(this, key, "클립보드 읽기 실패: ${error.javaClass.simpleName}")
            finish()
            return
        }

        if (text == null) {
            if (attempt < 3) {
                handler.postDelayed({ shareClipboard(key, attempt + 1) }, 200)
            } else {
                Diagnostics.set(this, key, "복사 직후의 새 텍스트 클립을 확인하지 못함")
                finish()
            }
            return
        }

        try {
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, text)
            }
            startActivity(Intent.createChooser(sendIntent, "복사한 텍스트 공유").apply {
                addFlags(Intent.FLAG_ACTIVITY_NO_ANIMATION)
            })
            Diagnostics.set(this, key, "공유창 실행 요청 완료 (텍스트 ${text.length}자)")
        } catch (error: Exception) {
            Diagnostics.set(this, key, "공유창 실행 실패: ${error.javaClass.simpleName}")
        }
        finish()
    }

    companion object {
        const val EXTRA_AUTOMATIC = "automatic"
        const val EXTRA_TRIGGERED_AT = "triggered_at"
    }
}
