package com.jwl.slackcopyshare

import android.accessibilityservice.AccessibilityService
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.os.SystemClock
import android.view.accessibility.AccessibilityEvent

class SlackCopyAccessibilityService : AccessibilityService() {
    private var lastTriggerAt = 0L
    private var lastSlackEventAt = 0L
    private var clipboard: ClipboardManager? = null
    private val clipListener = ClipboardManager.OnPrimaryClipChangedListener {
        Diagnostics.increment(this, "clipChangeCount")
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        Diagnostics.set(this, "service", "접근성 서비스 연결됨")
        clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard?.addPrimaryClipChangedListener(clipListener)
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return
        val packageName = event.packageName?.toString() ?: return
        val eventName = AccessibilityEvent.eventTypeToString(event.eventType)
        if (packageName != "com.Slack") {
            if (SystemClock.elapsedRealtime() - lastSlackEventAt < 10000L &&
                event.eventType in setOf(
                    AccessibilityEvent.TYPE_VIEW_CLICKED,
                    AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED,
                    AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
                )
            ) {
                Diagnostics.set(this, "neighborEvent", "$packageName / $eventName")
            }
            return
        }

        lastSlackEventAt = SystemClock.elapsedRealtime()
        Diagnostics.increment(this, "slackEventCount")
        Diagnostics.set(this, "lastSlackEvent", eventName)
        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED -> Diagnostics.increment(this, "contentEventCount")
            AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED -> Diagnostics.increment(this, "notificationEventCount")
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED -> Diagnostics.increment(this, "windowEventCount")
        }

        val labels = buildList {
            event.text?.forEach { add(it.toString()) }
            event.contentDescription?.let { add(it.toString()) }
            if (event.eventType == AccessibilityEvent.TYPE_VIEW_CLICKED) {
                event.source?.text?.let { add(it.toString()) }
                event.source?.contentDescription?.let { add(it.toString()) }
            }
        }
        val isCopy = labels.any { it.trim().lowercase() in COPY_LABELS }
        val labelSummary = labels.joinToString(" ").lowercase()
        val isCopyNotice = event.eventType == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED &&
            COPY_NOTICE_MARKERS.any { labelSummary.contains(it) }
        if (event.eventType == AccessibilityEvent.TYPE_NOTIFICATION_STATE_CHANGED) {
            Diagnostics.set(this, "lastNotification", if (isCopyNotice) "복사 완료 문구 포함" else if (labels.all { it.isBlank() }) "문구 없음" else "다른 문구")
        }
        if (isCopy && event.eventType != AccessibilityEvent.TYPE_VIEW_CLICKED) {
            Diagnostics.increment(this, "copyHintCount")
            Diagnostics.set(this, "lastCopyHint", eventName)
        }
        if (isCopyNotice) {
            Diagnostics.increment(this, "copyNoticeCount")
            requestShare("Slack 복사 완료 알림")
        }
        if (event.eventType != AccessibilityEvent.TYPE_VIEW_CLICKED) return

        Diagnostics.increment(this, "clickCount")
        val clickKind = if (isCopy) "복사 문구" else if (labels.all { it.isBlank() }) "문구 없음" else if (labelSummary.contains("복사") || labelSummary.contains("copy")) "복사 단어 포함" else "다른 문구"
        Diagnostics.set(this, "lastClick", "$clickKind / ${event.className?.toString()?.substringAfterLast('.') ?: "클래스 없음"}")
        if (!isCopy) return

        requestShare("Slack 복사 메뉴 클릭")
    }

    private fun requestShare(reason: String) {
        val now = System.currentTimeMillis()
        if (now - lastTriggerAt < 1500) return
        lastTriggerAt = now
        Diagnostics.increment(this, "copyCount")
        Diagnostics.set(this, "automatic", "$reason → 브릿지 화면 요청")

        try {
            startActivity(Intent(this, ShareBridgeActivity::class.java).apply {
                putExtra(ShareBridgeActivity.EXTRA_AUTOMATIC, true)
                putExtra(ShareBridgeActivity.EXTRA_TRIGGERED_AT, now)
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_MULTIPLE_TASK or Intent.FLAG_ACTIVITY_EXCLUDE_FROM_RECENTS or Intent.FLAG_ACTIVITY_NO_ANIMATION)
            })
        } catch (error: Exception) {
            Diagnostics.set(this, "automatic", "브릿지 화면 요청 실패: ${error.javaClass.simpleName}")
        }
    }

    override fun onInterrupt() {
        Diagnostics.set(this, "service", "접근성 서비스 중단됨")
    }

    override fun onDestroy() {
        clipboard?.removePrimaryClipChangedListener(clipListener)
        super.onDestroy()
    }

    companion object {
        private val COPY_LABELS = setOf("복사", "텍스트 복사", "메시지 복사", "클립보드에 복사", "copy", "copy text", "copy message", "copy to clipboard")
        private val COPY_NOTICE_MARKERS = setOf("클립보드에 복사", "복사되었습니다", "copied to clipboard", "copied")
    }
}
