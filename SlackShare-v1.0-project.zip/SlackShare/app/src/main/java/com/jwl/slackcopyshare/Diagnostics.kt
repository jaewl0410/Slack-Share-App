package com.jwl.slackcopyshare

import android.content.Context

object Diagnostics {
    private const val PREFS = "diagnostics"

    fun set(context: Context, key: String, value: String) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(key, value).apply()
    }

    fun increment(context: Context, key: String) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        prefs.edit().putInt(key, prefs.getInt(key, 0) + 1).apply()
    }

    fun summary(context: Context): String {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        return listOf(
            "서비스: ${prefs.getString("service", "아직 연결 기록 없음")}",
            "Slack 전체 이벤트: ${prefs.getInt("slackEventCount", 0)}회",
            "Slack 클릭 이벤트: ${prefs.getInt("clickCount", 0)}회",
            "Slack 화면 변경 이벤트: ${prefs.getInt("contentEventCount", 0)}회",
            "Slack 창 전환 이벤트: ${prefs.getInt("windowEventCount", 0)}회",
            "Slack 알림 이벤트: ${prefs.getInt("notificationEventCount", 0)}회",
            "복사 완료 알림 감지: ${prefs.getInt("copyNoticeCount", 0)}회",
            "마지막 Slack 알림: ${prefs.getString("lastNotification", "없음")}",
            "복사 문구 감지: ${prefs.getInt("copyCount", 0)}회",
            "복사 문구가 보인 다른 이벤트: ${prefs.getInt("copyHintCount", 0)}회",
            "클립보드 변경 신호: ${prefs.getInt("clipChangeCount", 0)}회",
            "마지막 Slack 이벤트: ${prefs.getString("lastSlackEvent", "없음")}",
            "복사 문구 이벤트: ${prefs.getString("lastCopyHint", "없음")}",
            "Slack 직후 다른 앱 이벤트: ${prefs.getString("neighborEvent", "없음")}",
            "마지막 클릭: ${prefs.getString("lastClick", "없음")}",
            "자동 경로: ${prefs.getString("automatic", "시도 전")}",
            "수동 경로: ${prefs.getString("manual", "시도 전")}",
        ).joinToString("\n")
    }
}
